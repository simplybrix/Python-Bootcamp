name = input("What is your name? ")
# variables lesson; how do you refer to your input again?
# you can add a variable to the beginning of the input such as above
# before: input("What is your name? ") ---> asked for input and went away
# now: name = input("What is your name? ") , including print function ----> asks for input and stores into variable, name
# then prints the variable name
print(name)