# 🚨 Don't change the code below 👇
height = input("enter your height in inches: ")
weight = input("enter your weight in pounds: ")
# 🚨 Don't change the code above 👆

#Write your code below this line 👇
weight_integer = int(weight)
height_integer = int(height)

bmi = weight_integer / height_integer / height_integer * 703
bmi_integer = int(bmi)

print(bmi_integer)
