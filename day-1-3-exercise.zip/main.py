#Write your code below this line 👇
# Brianna Scott
# October 5, 2021
# Purpose is to write a program that prints the number of characters in a user's Name
print("Welcome to the Character Counter Simulator.")
print(len(input("Hello, what is your name? ")))






