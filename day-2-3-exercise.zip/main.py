# 🚨 Don't change the code below 👇
age = input("What is your current age? ")
# 🚨 Don't change the code above 👆
#Write your code below this line 👇
years = 90 - int(age)
months = round(years * 12)
weeks = round(years * 52)
days = round(years * 365)

print(f"You have {months} months, {weeks} weeks, and {days} days until you turn 90 years old.")
print("Goodbye, and Happy Halloween!")








